# Bill of Materials — Fingerprint Open

Total estimated cost: **~$12–18 USD**

| Component | Purpose | Example Part | Est. Cost |
|---|---|---|---|
| ESP32-S3 DevKit | Main MCU (FFT-capable) | ESP32-S3-DevKitC-1 | $5–8 |
| OV7670 Camera Module | Optical finger sensor | OV7670 + FIFO | $2–3 |
| MLX90614 | IR thermopile (thermal gate) | MLX90614ESF-AAA | $5–8 |
| TCRT5000 (x2) | IR scatter liveness sensor | TCRT5000L | $0.50 |
| Capacitive touch matrix | Grid-based fingerprint | MPR121 breakout | $3–5 |
| 3.3V LDO regulator | Power supply | AMS1117-3.3 | $0.20 |
| Misc resistors/caps | Pull-ups, decoupling | — | $0.50 |

## Notes

- **OV7670** can be replaced with R307 fingerprint module in raw image mode (UART). R307 costs ~$5 and already has a lens and IR LED built in.
- **MLX90614** is the cleanest thermal solution. A cheap NTC thermistor (~$0.10) can substitute with lower accuracy.
- **MPR121** provides 12 capacitive channels — use two for a 24-channel grid, or expand with CD4051 multiplexer for full 80-cell grid.
- **TCRT5000** pair: mount one direct (specular), one at ~5mm offset (diffuse scatter). The ratio between them is the IR liveness score.

## Alternative MCU Options

| MCU | FFT Support | Cost | Notes |
|---|---|---|---|
| ESP32-S3 | Hardware accelerated | $3–5 | Recommended |
| STM32F4 | FPU + DSP instructions | $4–8 | Best for bare-metal |
| STM32F103 (Blue Pill) | Software FFT only | $1–2 | Slower but works |
| Raspberry Pi Pico | Software FFT | $4 | MicroPython friendly |
