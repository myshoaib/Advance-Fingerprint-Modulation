/**
 * fingerprint-open — Verification Module
 * Author: Shoaib | Co-Author: Claude.ai (Anthropic)
 * License: MIT
 * Target: ESP32-S3 (FFT-capable, Arduino framework)
 *
 * Concept: Partial fingerprint matching with spatial distance metric.
 * User may touch partially or at angle — only a subset of minutiae
 * points will be captured. Verification passes if enough points
 * match with correct inter-point distances.
 *
 * Liveness checks run FIRST before pattern match — three independent gates.
 */

#include <Arduino.h>
#include <arduinoFFT.h>
#include <EEPROM.h>
#include <math.h>

// --- Reuse same config and structs from enrollment.cpp ---
// In a real project, move these to a shared header file: fingerprint.h

#define GRID_COLS           8
#define GRID_ROWS           10
#define GRID_CELLS          (GRID_COLS * GRID_ROWS)
#define THERMAL_PIN         34
#define SENSOR_PIN_BASE     4
#define TEMP_MIN            30.0
#define TEMP_MAX            37.5
#define EEPROM_SIZE         1024
#define TEMPLATE_ADDR       0

// Matching thresholds
#define MATCH_DISTANCE_TOL  0.08   // How close distances must be (normalized)
#define MATCH_MIN_POINTS    4      // Minimum matching points to accept
#define ORIENTATION_TOL     0.15   // Ridge orientation tolerance

struct MinutiaePoint {
  float x;
  float y;
  float orientation;
  float strength;
};

struct FingerprintTemplate {
  uint8_t       userID;
  uint8_t       pointCount;
  MinutiaePoint points[20];
  float         distanceMatrix[20][20];
  bool          valid;
};

float gridCapture[GRID_ROWS][GRID_COLS];
FingerprintTemplate storedTemplate;
FingerprintTemplate liveTemplate;

// --- Liveness Checks (same as enrollment, run again at verification) ---

bool livenessCheckThermal() {
  int raw      = analogRead(THERMAL_PIN);
  float voltage = (raw / 4095.0) * 3.3;
  float tempC   = (voltage - 0.5) * 100.0;
  Serial.printf("[LIVENESS] Thermal: %.1f C\n", tempC);
  return (tempC >= TEMP_MIN && tempC <= TEMP_MAX);
}

bool livenessCheckEntropy() {
  float mean = 0.0;
  for (int r = 0; r < GRID_ROWS; r++)
    for (int c = 0; c < GRID_COLS; c++)
      mean += gridCapture[r][c];
  mean /= GRID_CELLS;

  float variance = 0.0;
  for (int r = 0; r < GRID_ROWS; r++)
    for (int c = 0; c < GRID_COLS; c++) {
      float diff = gridCapture[r][c] - mean;
      variance += diff * diff;
    }
  variance /= GRID_CELLS;

  float entropy = sqrt(variance);
  Serial.printf("[LIVENESS] Entropy: %.4f\n", entropy);
  return (entropy > 0.05);
}

/**
 * IR Subsurface Scatter liveness check.
 * Real flesh scatters IR diffusely — ratio of diffuse to specular return
 * is high for real finger, near zero for fake.
 *
 * In hardware: use TCRT5000 or similar IR reflectance sensor.
 * Two readings: direct (specular) and offset (diffuse scatter).
 * Here: analog pins A0 (specular) and A1 (diffuse offset) as example.
 */
bool livenessCheckIRScatter() {
  float specular = analogRead(35) / 4095.0;
  float diffuse  = analogRead(36) / 4095.0;

  float scatterRatio = (specular > 0.01) ? (diffuse / specular) : 0.0;
  Serial.printf("[LIVENESS] IR Scatter Ratio: %.3f\n", scatterRatio);

  // Real finger: ratio > 0.3 (tune per sensor and lighting)
  return (scatterRatio > 0.3);
}

// --- Grid Capture ---

void captureGrid() {
  for (int r = 0; r < GRID_ROWS; r++) {
    for (int c = 0; c < GRID_COLS; c++) {
      int pin = SENSOR_PIN_BASE + (c % 10);
      float raw = touchRead(pin);
      gridCapture[r][c] = constrain(raw / 100.0, 0.0, 1.0);
    }
  }
}

// --- Feature Extraction (same FFT method) ---

float computeRegionOrientation(int rowStart, int colStart, int size) {
  const uint16_t N = 16;
  double vReal[N], vImag[N];
  int idx = 0;

  for (int r = rowStart; r < rowStart + size && r < GRID_ROWS && idx < N; r++)
    for (int c = colStart; c < colStart + size && c < GRID_COLS && idx < N; c++)
      vReal[idx++] = gridCapture[r][c];

  while (idx < N) vReal[idx++] = 0.0;
  for (int i = 0; i < N; i++) vImag[i] = 0.0;

  ArduinoFFT<double> FFT(vReal, vImag, N, 1000.0);
  FFT.windowing(FFTWindow::Hamming, FFTDirection::Forward);
  FFT.compute(FFTDirection::Forward);
  FFT.complexToMagnitude();

  double maxMag = 0.0;
  int peakBin = 1;
  for (int i = 1; i < N / 2; i++) {
    if (vReal[i] > maxMag) { maxMag = vReal[i]; peakBin = i; }
  }
  return (float)peakBin / (N / 2);
}

uint8_t extractMinutiae(MinutiaePoint* points, uint8_t maxPoints) {
  uint8_t count = 0;
  for (int r = 1; r < GRID_ROWS - 1 && count < maxPoints; r++) {
    for (int c = 1; c < GRID_COLS - 1 && count < maxPoints; c++) {
      float center = gridCapture[r][c];
      bool isLocalPeak =
        center > gridCapture[r-1][c] &&
        center > gridCapture[r+1][c] &&
        center > gridCapture[r][c-1] &&
        center > gridCapture[r][c+1];

      if (isLocalPeak && center > 0.3) {
        points[count].x           = (float)c / GRID_COLS;
        points[count].y           = (float)r / GRID_ROWS;
        points[count].orientation = computeRegionOrientation(r-1, c-1, 3);
        points[count].strength    = center;
        count++;
      }
    }
  }
  return count;
}

// --- Matching Engine ---

/**
 * Core matching: Shoaib's spatial distance metric.
 *
 * For each live minutiae point (i), find the closest stored point (j).
 * Then verify that surrounding inter-point distances match the stored
 * distance matrix within tolerance.
 *
 * This works even with PARTIAL touch — only a subset of points
 * need to match. MATCH_MIN_POINTS defines the acceptance threshold.
 */
int countMatchingPoints() {
  int matched = 0;

  for (int i = 0; i < liveTemplate.pointCount; i++) {
    // Find nearest stored point by position
    float bestPosDist = 999.0;
    int   bestJ       = -1;

    for (int j = 0; j < storedTemplate.pointCount; j++) {
      float dx = liveTemplate.points[i].x - storedTemplate.points[j].x;
      float dy = liveTemplate.points[i].y - storedTemplate.points[j].y;
      float d  = sqrt(dx*dx + dy*dy);
      if (d < bestPosDist) { bestPosDist = d; bestJ = j; }
    }

    if (bestJ == -1 || bestPosDist > MATCH_DISTANCE_TOL) continue;

    // Orientation check
    float orientDiff = fabs(liveTemplate.points[i].orientation
                          - storedTemplate.points[bestJ].orientation);
    if (orientDiff > ORIENTATION_TOL) continue;

    // Distance matrix consistency check
    // Pick a second live point and verify distance ratio matches stored
    bool distConsistent = true;
    for (int i2 = 0; i2 < liveTemplate.pointCount && i2 != i; i2++) {
      // Find corresponding stored point for i2
      float bestDist2 = 999.0;
      int   bestJ2    = -1;
      for (int j2 = 0; j2 < storedTemplate.pointCount && j2 != bestJ; j2++) {
        float dx = liveTemplate.points[i2].x - storedTemplate.points[j2].x;
        float dy = liveTemplate.points[i2].y - storedTemplate.points[j2].y;
        float d  = sqrt(dx*dx + dy*dy);
        if (d < bestDist2) { bestDist2 = d; bestJ2 = j2; }
      }
      if (bestJ2 == -1) continue;

      // Live distance between point i and i2
      float dx_live = liveTemplate.points[i].x - liveTemplate.points[i2].x;
      float dy_live = liveTemplate.points[i].y - liveTemplate.points[i2].y;
      float liveDist = sqrt(dx_live*dx_live + dy_live*dy_live);

      // Stored distance between matched pair
      float storedDist = storedTemplate.distanceMatrix[bestJ][bestJ2];

      if (fabs(liveDist - storedDist) > MATCH_DISTANCE_TOL) {
        distConsistent = false;
        break;
      }
    }

    if (distConsistent) matched++;
  }

  return matched;
}

// --- Verification Main ---

/**
 * Full verification sequence:
 * 1. Capture grid
 * 2. Three liveness gates (thermal, entropy, IR scatter)
 * 3. Extract minutiae
 * 4. Match against stored template
 * 5. Accept if matched points >= MATCH_MIN_POINTS
 */
bool verifyFinger() {
  Serial.println("[VERIFY] Place finger on sensor...");
  delay(1000);
  captureGrid();

  // Gate 1: Thermal
  if (!livenessCheckThermal()) {
    Serial.println("[VERIFY] REJECTED — Thermal gate failed.");
    return false;
  }

  // Gate 2: Capacitive entropy
  if (!livenessCheckEntropy()) {
    Serial.println("[VERIFY] REJECTED — Entropy gate failed.");
    return false;
  }

  // Gate 3: IR subsurface scatter
  if (!livenessCheckIRScatter()) {
    Serial.println("[VERIFY] REJECTED — IR scatter gate failed.");
    return false;
  }

  Serial.println("[VERIFY] Liveness confirmed. Running pattern match...");

  // Extract live minutiae
  liveTemplate.pointCount = extractMinutiae(liveTemplate.points, 20);
  Serial.printf("[VERIFY] Live points captured: %d\n", liveTemplate.pointCount);

  // Match
  int matchCount = countMatchingPoints();
  Serial.printf("[VERIFY] Matching points: %d / %d required\n",
                matchCount, MATCH_MIN_POINTS);

  if (matchCount >= MATCH_MIN_POINTS) {
    Serial.println("[VERIFY] ✅ AUTHENTICATED — User verified.");
    return true;
  } else {
    Serial.println("[VERIFY] ❌ REJECTED — Insufficient pattern match.");
    return false;
  }
}

// --- Arduino Entry Points ---

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("[BOOT] Fingerprint Open — Verification Module");
  Serial.println("[BOOT] Author: Shoaib | Claude.ai (Anthropic) | MIT License");

  // Load stored template from EEPROM
  EEPROM.begin(EEPROM_SIZE);
  EEPROM.get(TEMPLATE_ADDR, storedTemplate);

  if (!storedTemplate.valid) {
    Serial.println("[BOOT] No enrolled template found. Run enrollment first.");
    while (true) delay(1000);
  }

  Serial.printf("[BOOT] Template loaded. User ID: %d | Points: %d\n",
                storedTemplate.userID, storedTemplate.pointCount);
}

void loop() {
  bool result = verifyFinger();

  // Add your action here: unlock relay, send signal, etc.
  if (result) {
    digitalWrite(LED_BUILTIN, HIGH);
    delay(2000);
    digitalWrite(LED_BUILTIN, LOW);
  }

  delay(3000); // Wait before next attempt
}
