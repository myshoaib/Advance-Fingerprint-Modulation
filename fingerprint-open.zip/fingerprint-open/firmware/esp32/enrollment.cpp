/**
 * fingerprint-open — Enrollment Module
 * Author: Shoaib | Co-Author: Claude.ai (Anthropic)
 * License: MIT
 * Target: ESP32-S3 (FFT-capable, Arduino framework)
 *
 * Concept: Grid-based fingerprint enrollment.
 * Finger surface (~16mm x 24mm) divided into NxM grid cells.
 * Each cell records capacitive or optical intensity value.
 * Multiple presses are averaged into a composite template.
 * Template stored as minutiae point cloud with spatial distances.
 *
 * NOTE: This is reference/sample code. Sensor pin assignments
 * and grid resolution must be tuned to your specific hardware.
 */

#include <Arduino.h>
#include <arduinoFFT.h>       // Install via Arduino Library Manager
#include <EEPROM.h>

// --- Configuration ---
#define GRID_COLS        8    // Horizontal grid divisions
#define GRID_ROWS        10   // Vertical grid divisions
#define GRID_CELLS       (GRID_COLS * GRID_ROWS)  // 80 cells total
#define ENROLLMENT_PRESSES  3  // Number of presses to average
#define THERMAL_PIN      34   // Analog pin for MLX90614 or NTC thermistor
#define SENSOR_PIN_BASE  4    // First capacitive touch pin
#define TEMP_MIN         30.0 // Minimum live finger temp (Celsius)
#define TEMP_MAX         37.5 // Maximum live finger temp (Celsius)
#define EEPROM_SIZE      1024
#define TEMPLATE_ADDR    0    // EEPROM address to store template

// --- Data Structures ---

// A single grid cell reading
struct GridCell {
  uint8_t col;
  uint8_t row;
  float   intensity;    // Capacitive charge or optical brightness (0.0 - 1.0)
};

// A minutiae point — key feature extracted from grid
struct MinutiaePoint {
  float x;             // Normalized x position (0.0 - 1.0)
  float y;             // Normalized y position (0.0 - 1.0)
  float orientation;   // Ridge direction in radians
  float strength;      // Feature confidence score
};

// Full fingerprint template stored per user
struct FingerprintTemplate {
  uint8_t        userID;
  uint8_t        pointCount;
  MinutiaePoint  points[20];   // Up to 20 key minutiae points
  float          distanceMatrix[20][20]; // Pairwise distances between points
  bool           valid;
};

// Global working grid
float gridCapture[GRID_ROWS][GRID_COLS];
float gridComposite[GRID_ROWS][GRID_COLS];
FingerprintTemplate enrolledTemplate;

// --- Liveness Check ---

/**
 * Thermal gate: read temperature and confirm it is a live finger.
 * Uses simple NTC thermistor or MLX90614 analog output.
 * Returns true if temperature is within live range.
 */
bool livenessCheckThermal() {
  int raw = analogRead(THERMAL_PIN);
  // Convert raw ADC to approximate Celsius (calibrate per sensor)
  float voltage = (raw / 4095.0) * 3.3;
  float tempC   = (voltage - 0.5) * 100.0; // Example: TMP36 conversion

  Serial.printf("[LIVENESS] Thermal: %.1f C\n", tempC);
  return (tempC >= TEMP_MIN && tempC <= TEMP_MAX);
}

/**
 * Capacitive entropy gate: a real finger has non-uniform charge
 * distribution. A fake (silicone, photo) is too uniform.
 * Computes spatial entropy of the grid and checks threshold.
 */
bool livenessCheckEntropy() {
  float mean = 0.0;
  for (int r = 0; r < GRID_ROWS; r++)
    for (int c = 0; c < GRID_COLS; c++)
      mean += gridCapture[r][c];
  mean /= GRID_CELLS;

  float variance = 0.0;
  for (int r = 0; r < GRID_ROWS; r++)
    for (int c = 0; c < GRID_COLS; c++) {
      float diff = gridCapture[r][c] - mean;
      variance += diff * diff;
    }
  variance /= GRID_CELLS;

  float entropy = sqrt(variance);  // Simplified spatial entropy metric
  Serial.printf("[LIVENESS] Entropy: %.4f\n", entropy);

  // Real finger: entropy > 0.05 (tune this threshold per sensor)
  return (entropy > 0.05);
}

// --- Grid Capture ---

/**
 * Capture one full grid reading from the sensor.
 * In real hardware: read each capacitive cell or scan optical array row by row.
 * Here: placeholder using touchRead() as example for ESP32 built-in touch pins.
 */
void captureGrid() {
  for (int r = 0; r < GRID_ROWS; r++) {
    for (int c = 0; c < GRID_COLS; c++) {
      // ESP32 has 10 capacitive touch pins (T0–T9)
      // In full implementation, use a multiplexer to expand to 80 cells
      int pin = SENSOR_PIN_BASE + (c % 10); // Simplified — expand with MUX
      float raw = touchRead(pin);
      gridCapture[r][c] = constrain(raw / 100.0, 0.0, 1.0); // Normalize
    }
  }
}

/**
 * Accumulate multiple captures into composite grid (averaging).
 */
void accumulateToComposite(int pressIndex) {
  for (int r = 0; r < GRID_ROWS; r++)
    for (int c = 0; c < GRID_COLS; c++) {
      if (pressIndex == 0)
        gridComposite[r][c] = gridCapture[r][c];
      else
        gridComposite[r][c] = (gridComposite[r][c] * pressIndex + gridCapture[r][c])
                               / (pressIndex + 1);
    }
}

// --- Feature Extraction (FFT-based ridge orientation) ---

/**
 * For each grid region, compute dominant ridge orientation using FFT.
 * This gives each region a spatial frequency signature.
 * Matching two regions: compare their FFT peak orientation.
 */
float computeRegionOrientation(int rowStart, int colStart, int size) {
  const uint16_t N = 16;
  double vReal[N], vImag[N];

  // Flatten a region into 1D signal (row-major)
  int idx = 0;
  for (int r = rowStart; r < rowStart + size && r < GRID_ROWS && idx < N; r++)
    for (int c = colStart; c < colStart + size && c < GRID_COLS && idx < N; c++)
      vReal[idx++] = gridComposite[r][c];

  while (idx < N) vReal[idx++] = 0.0; // Zero-pad
  for (int i = 0; i < N; i++) vImag[i] = 0.0;

  ArduinoFFT<double> FFT(vReal, vImag, N, 1000.0);
  FFT.windowing(FFTWindow::Hamming, FFTDirection::Forward);
  FFT.compute(FFTDirection::Forward);
  FFT.complexToMagnitude();

  // Find peak frequency bin (skip DC at bin 0)
  double maxMag = 0.0;
  int peakBin = 1;
  for (int i = 1; i < N / 2; i++) {
    if (vReal[i] > maxMag) {
      maxMag = vReal[i];
      peakBin = i;
    }
  }

  // Return orientation as normalized angle
  return (float)peakBin / (N / 2);
}

// --- Minutiae Extraction ---

/**
 * Extract key minutiae points from composite grid.
 * A minutiae point is a local intensity peak (ridge ending or bifurcation).
 */
uint8_t extractMinutiae(MinutiaePoint* points, uint8_t maxPoints) {
  uint8_t count = 0;

  for (int r = 1; r < GRID_ROWS - 1 && count < maxPoints; r++) {
    for (int c = 1; c < GRID_COLS - 1 && count < maxPoints; c++) {
      float center = gridComposite[r][c];

      // Local maximum check (simplified ridge ending/bifurcation detection)
      bool isLocalPeak =
        center > gridComposite[r-1][c] &&
        center > gridComposite[r+1][c] &&
        center > gridComposite[r][c-1] &&
        center > gridComposite[r][c+1];

      if (isLocalPeak && center > 0.3) { // Threshold: only strong features
        points[count].x           = (float)c / GRID_COLS;
        points[count].y           = (float)r / GRID_ROWS;
        points[count].orientation = computeRegionOrientation(r-1, c-1, 3);
        points[count].strength    = center;
        count++;
      }
    }
  }
  return count;
}

/**
 * Build distance matrix between all extracted minutiae points.
 * This is the spatial metric Shoaib described:
 * distance between sample points is preserved and matched during verification.
 */
void buildDistanceMatrix(FingerprintTemplate* tmpl) {
  for (int i = 0; i < tmpl->pointCount; i++) {
    for (int j = 0; j < tmpl->pointCount; j++) {
      float dx = tmpl->points[i].x - tmpl->points[j].x;
      float dy = tmpl->points[i].y - tmpl->points[j].y;
      tmpl->distanceMatrix[i][j] = sqrt(dx*dx + dy*dy);
    }
  }
}

// --- Enrollment Main ---

/**
 * Full enrollment sequence for one user.
 * - Prompts user to press finger ENROLLMENT_PRESSES times
 * - Runs liveness checks on each press
 * - Builds composite grid
 * - Extracts minutiae template
 * - Saves to EEPROM
 */
bool enrollUser(uint8_t userID) {
  Serial.println("[ENROLL] Starting enrollment. Please press finger...");
  memset(gridComposite, 0, sizeof(gridComposite));

  for (int press = 0; press < ENROLLMENT_PRESSES; press++) {
    Serial.printf("[ENROLL] Press %d of %d\n", press + 1, ENROLLMENT_PRESSES);
    delay(1500); // Wait for finger placement

    captureGrid();

    // Liveness checks on every press
    if (!livenessCheckThermal()) {
      Serial.println("[ENROLL] REJECTED — Thermal liveness failed. Not a live finger.");
      return false;
    }
    if (!livenessCheckEntropy()) {
      Serial.println("[ENROLL] REJECTED — Entropy liveness failed. Possible fake.");
      return false;
    }

    accumulateToComposite(press);
    Serial.println("[ENROLL] Press accepted.");
    delay(500);
  }

  // Extract template
  enrolledTemplate.userID     = userID;
  enrolledTemplate.pointCount = extractMinutiae(enrolledTemplate.points, 20);
  buildDistanceMatrix(&enrolledTemplate);
  enrolledTemplate.valid      = true;

  // Save to EEPROM
  EEPROM.begin(EEPROM_SIZE);
  EEPROM.put(TEMPLATE_ADDR, enrolledTemplate);
  EEPROM.commit();

  Serial.printf("[ENROLL] Done. %d minutiae points stored for user %d.\n",
                enrolledTemplate.pointCount, userID);
  return true;
}

// --- Arduino Entry Points ---

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("[BOOT] Fingerprint Open — Enrollment Module");
  Serial.println("[BOOT] Author: Shoaib | Claude.ai (Anthropic) | MIT License");

  enrollUser(1); // Enroll user ID 1
}

void loop() {
  // Enrollment is one-time. Nothing in loop.
  delay(10000);
}
