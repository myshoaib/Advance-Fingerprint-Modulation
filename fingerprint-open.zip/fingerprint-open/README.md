# 🔓 Fingerprint Authentication — Open & Free

---

> *"Does man think that We cannot reassemble his bones? Yes indeed, We are able to restore even his very fingertips."*
> **— Surah Al-Qiyamah (The Resurrection), Chapter 75, Verses 3–4 | القرآن الكريم**

*Allah preserved the uniqueness of every human fingerprint as a sign. We now return that knowledge to the people freely.*

---

## 📢 PUBLIC TECHNICAL DISCLOSURE

**Date:** March 28, 2026
**Author:** Shoaib
**Co-Authors:** Claude.ai (Anthropic), DeepSeek.ai

The fingerprint sensor industry has long treated its core mechanism as proprietary and secret. It is not. It is simple physics and basic signal processing — and we are declaring it open here, publicly, permanently.

> *"The proprietary label on fingerprint modules was always about business protection, not technical secrecy. The science has been open for 30 years."*
> — Claude.ai

---

## 🧠 The Mechanism (Plain Language)

### 1. Enrollment
The finger is sampled in a grid. Each grid cell records its data point. Multiple presses build a composite map. Stored as a lightweight geometric template — not a photograph.

### 2. Verification
User touches partially or fully. The processor extracts 4–5 sample points, measures the spatial distances between them, and matches against the stored template. Partial touch is enough. An FFT-capable microcontroller handles this in milliseconds.

### 3. Liveness Detection

| Method | How It Works | What It Rejects |
|---|---|---|
| Thermal Gate | IR temp sensor checks 30–37°C | Silicone molds, photos, gelatin |
| Capacitive Entropy | Real finger has non-uniform charge gradient | Any flat uniform fake |
| IR Subsurface Scatter | Live flesh scatters IR diffusely | Any solid surface fake |

---

## ⚙️ Hardware (Total ~$15)

See [`hardware/bom.md`](hardware/bom.md) for full Bill of Materials.

- **MCU:** ESP32-S3 or STM32F4 (FFT-capable)
- **Sensor:** OV7670 camera module or R307 in raw image mode
- **Thermal:** MLX90614 IR thermopile (~$2)
- **Capacitive:** Standard touch grid matrix
- **Firmware base:** NIST NBIS (public domain) / SourceAFIS (Apache 2.0)

---

## 📁 Repository Structure

```
fingerprint-open/
├── README.md              ← This declaration
├── LICENSE                ← MIT License
├── docs/
│   └── theory.md          ← Full technical theory
├── firmware/
│   └── esp32/
│       ├── enrollment.cpp  ← Grid-based enrollment
│       └── verification.cpp← Partial match + liveness
└── hardware/
    └── bom.md             ← Bill of materials
```

---

## 📜 Legal Status — Prior Art Declaration

This disclosure is **prior art** as of **March 28, 2026**.

Any patent filed after this date covering this specific combination:
- Thermal gate liveness check
- Capacitive entropy liveness check
- IR subsurface scatter liveness check
- Combined as a unified fingerprint authentication pipeline

...is **invalidated** by this public record.

**No permission needed. No license fee. No NDA. Build it. Ship it. It is yours.**

---

## 📄 License

MIT License — see [LICENSE](LICENSE)

---

#OpenSource #Biometrics #FingerprintSensor #OpenHardware #EmbeddedSystems #PriorArt
